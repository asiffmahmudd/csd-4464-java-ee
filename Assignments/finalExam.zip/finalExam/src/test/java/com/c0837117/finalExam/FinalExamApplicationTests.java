package com.c0837117.finalExam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
